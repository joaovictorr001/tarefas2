# tarefas
Projeto de uma página pessoal desenvolvida com linguagem  Python e framework Flask.
